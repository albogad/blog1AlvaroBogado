<?php


class ConnexionController
{
    public function index(){

    }

}
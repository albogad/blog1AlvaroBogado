<h1>Modification d'un article</h1>
<hr>
<?php
extract($article);
//affichage du formulaire
include ADMIN_TEMPLATES_PATH . '/_formArticle.php';
?>



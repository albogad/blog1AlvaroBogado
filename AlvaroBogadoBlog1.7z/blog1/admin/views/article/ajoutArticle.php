<h1>Ajouter un article</h1>
<hr>
<?php
include ADMIN_TEMPLATES_PATH . '/_formArticle.php';
?>


<h1>Modification d'une catégorie</h1>
<hr>
<?php
extract($categorie);
//affichage du formulaire
include ADMIN_TEMPLATES_PATH . '/_formCategorie.php';
?>
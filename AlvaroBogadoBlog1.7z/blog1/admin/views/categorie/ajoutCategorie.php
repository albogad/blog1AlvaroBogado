<h1>Ajouter une catégorie</h1>
<hr>
<?php
include ADMIN_TEMPLATES_PATH . '/_formCategorie.php';
?>

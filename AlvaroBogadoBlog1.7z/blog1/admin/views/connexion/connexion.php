<h1>Connexion</h1>
<form action="index.php?p=login" method="post">
    <div class="form-group">
        <label for="email">Identifiant</label>
        <input type="email" name="email" class="form-control" id="email">
    </div>
    <div class="form-group">
        <label for="mdp">Mot de passe</label>
        <input type="password" name="mdp" class="form-control" id="mdp" >
    </div>
    <input type="submit" value="Connexion" name="formconnexion" class="btn btn-primary">
</form>

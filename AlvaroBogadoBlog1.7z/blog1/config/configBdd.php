<?php
 $pdo = new PDO("mysql:host=localhost;dbname=base1;charset=utf8;port=3306", "root", "",
array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
 $req = $pdo->prepare("SELECT * FROM categorie");
 $categories = $req->fetchAll(PDO::FETCH_OBJ);
 
// ON article.id_categorie = categorie.id_categorie

 $req->execute();

 
//variables globales de la Bdd
define('HOST', 'localhost');
define('DB', 'base1');
define('PORT', '3306');
define('ID', 'root');
define('PWD', '');
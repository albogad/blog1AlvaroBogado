<section>
    <h1>Bienvenue sur mon blog</h1>
    <div>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus adipisci at atque distinctio dolorem doloremque dolores dolorum facilis harum hic illo in, libero magnam maxime nihil nisi sed tempore voluptates?
        </p>
        <img src="img/fleurs1.jpg" alt="">
    </div>
</section>
<aside>
    <h2>Derniers articles</h2>
</aside>
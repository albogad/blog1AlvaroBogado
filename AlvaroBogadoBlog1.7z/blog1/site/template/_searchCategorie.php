<?php $conn = new PDO("mysql:host=localhost;dbname=base1;charset=utf8;port=3306", "root", "", []); 

$req = $conn->prepare("SELECT * FROM categorie");

$req->execute(); 

$categories = $req->fetchAll(PDO::FETCH_OBJ);



?>

<form action="#" method="post" name="searchCategorie">
   <select name="menu_categorie">

   		<!-- <option value="Meilleures plages en Asie">Meilleures plages en Asie</option>
   		<option value="Meilleures plages d'Europe">Meilleures plages d'Europe</option>
   		<option value="Meilleures plages d'Amérique">Meilleures plages d'Amérique</option> -->
   		<?php foreach ($categories as $categorie):?>

   		 <option value="<?php echo $categorie->id_categorie ?>">
   			<?php echo $categorie->nom_categorie ?>
   				
   		</option>

   	<?php endforeach; ?>
   		
   </select>
 <input type="submit" name="Valider" value="Valider"> 
 
</form>
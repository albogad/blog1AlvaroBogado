<nav>
    <ul>
        <li><a href="../admin/index.php">Admin</a></li>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="articles.php">Articles</a></li>
    </ul>
</nav>
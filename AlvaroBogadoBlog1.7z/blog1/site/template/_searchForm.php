<form action="#" method="post" name="searchForm">
    <input type="text" name="searchArticle">
    <button>Rechercher</button>
</form>
